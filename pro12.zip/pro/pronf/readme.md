

use samplenf;
create table donorn(name varchar(255),age int,addr varchar(255),ph varchar(255));
